export const api = {
  commodityList: '/steelserver/commodity/list',
  historyList: '/steelserver/commodity/historyList',
  listType: '/steelserver/commodity/listType'
}